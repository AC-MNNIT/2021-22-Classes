#include<bits/stdc++.h>
using namespace std;
int main(){
	vector<int> ar = { 1, 2, 3, 4, 5 }; 
	vector<int>::iterator itr = ar.begin();
	
	advance(itr, 3); // Using advance() to increment iterator position points to 4
	
					// Displaying iterator position
	cout << "The position of iterator after advancing is : ";
	cout << *itr << " ";
	
	return 0;
	
}

