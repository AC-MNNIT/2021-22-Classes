#include <bits/stdc++.h>
using namespace std;
int main(){
	vector<int> ar = { 1, 2, 3, 4, 5 };  // [0,5) ->[ ar.begin(),ar.end() )
    vector<int>::iterator itr;
    cout << "The vector elements are : ";
    for(itr = ar.begin(); itr != ar.end(); itr++)
        cout << *itr << " ";
    cout<<endl ;
    for(auto i:ar){
        cout<<i<<endl ;
    }  
    return 0;
}
