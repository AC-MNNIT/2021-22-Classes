#include <iostream>
#include <vector>
#include <utility>
using namespace std;

int main(){
	// defining a pair
	pair<string, double> p("pi", 3.14);
	// pair<pair<int,int>,string> ;
	// // ((x,y),"ninja"),_ _ _ _ ;

	cout << p.first << " ";
	cout << p.second << endl;

	pair<string, double> p1 = make_pair("INF",100000.00) ;


	cout << p1.first << " ";
	cout << p1.second << endl;

	p1.swap(p) ;

	cout<<"-----------------"<<endl ;
	cout<<"p1"<<endl ;
	cout << p1.first << " ";
	cout << p1.second << endl;

	cout<<"p"<<endl ;

	cout << p.first << " ";
	cout << p.second << endl;

	

	return 0;
}

